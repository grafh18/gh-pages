var img1;
var img2;
var img3;
function preload () {
  img1 = load Image ("Moon12.jpg");
  img2 = load Image ("tree12.jpg");
  img3 = load Image ("tree123.png");
}

function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(220);
  image (img1,50,0);
  image (img2, 100, 100, mouseX*2,mouseY*2);
  image (img3, 250, 230,mouseX*3,mouseY*3);
   colorMode(RGB, 255, 255, 255, 1);
  textFont('Arial');
  text ("Happy Halloween", 30,30);
  textSize(18);
  fill (255, 165, 0);
  Stroke (255);

}