function setup() {
  createCanvas(500, 500);
  angleMode(DEGREES);
  print ('Player One');
}

function draw() {
  background(220);
  colorMode(RGB, 255, 255, 255, 1);
  game (150,150);
  game (170,160);
  for (var x = 20; x < width + 65; x += 65){
    game (x,30);
  }
}
function game (x,y) {
  push();
  translate (60,60);
  stroke (2);
  strokeWeight(50);
  rect (100,120, 80, 80)
  fill (221, 166, 224);
  scale (0.5);
  rotate (35);
  pop();
}